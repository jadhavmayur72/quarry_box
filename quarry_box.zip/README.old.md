# quarry_box
 using thunk 
